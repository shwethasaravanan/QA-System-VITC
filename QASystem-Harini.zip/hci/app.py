from flask import Flask, render_template, request
from nlp_module import preprocess_text, build_tfidf_model, process_query, questions

app = Flask(__name__, static_url_path='/static')

# Initialize TF-IDF model
tfidf_matrix, tfidf_vectorizer = build_tfidf_model(questions)

@app.route('/')
def index():
    return render_template('index.html', answer="")

@app.route('/answer', methods=['POST'])
def answer():
    user_query = request.form['query']
    best_match_idx, best_match_answer = process_query(user_query, tfidf_vectorizer, tfidf_matrix)
    return render_template('index.html', answer=best_match_answer)

if __name__ == "__main__":
    app.run(debug=True)
